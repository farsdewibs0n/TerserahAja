-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2019 at 02:44 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bunda`
--

-- --------------------------------------------------------

--
-- Table structure for table `curhatan`
--

CREATE TABLE `curhatan` (
  `id_curhat` int(11) NOT NULL,
  `isi_curhat` text NOT NULL,
  `judul_curhat` text NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `curhatan`
--

INSERT INTO `curhatan` (`id_curhat`, `isi_curhat`, `judul_curhat`, `tanggal`) VALUES
(13, 'Hallo min,,, ini pertama kali saya curhat disini bun,, saya merasa ada perubahan pada diri saya semenjak temen2 semua udah punya kesibukan masing2 dan sudah ', 'Masalah Diri', '0000-00-00 00:00:00'),
(14, 'Halo min, aku mau curhat lagi.. Semoga dibales.. Beberapa bulan ini aku selalu ngerasa cemas, ketakutan karena ngebayangin hal-hal yang menakutkan buatku, seperti kematian orang2 ', 'Seram', '0000-00-00 00:00:00'),
(15, 'min, bagaimana cara agar menghilangkan sifat malas dan suka menunda-nunda? Saya takut penyakit malas saya sudah akut. ', 'Hilangkan Sifat malas', '0000-00-00 00:00:00'),
(16, 'aku sakit hati karna dia berdua denganya', 'sakit hati', '0000-00-00 00:00:00'),
(17, 'wjwiwiehwiewe', 'curhat dong hehehe', '0000-00-00 00:00:00'),
(18, 'kemaren saya ke hoya', 'di apakan wanita', '0000-00-00 00:00:00'),
(19, 'jfewijfiefief', 'aku sayang adit`', '0000-00-00 00:00:00'),
(20, 'aku mencintai mu pipah', 'aku dan pipah', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `nama`, `password`) VALUES
(25, 'farasw', 'Faras Wibusana', '$2y$10$OJyaHxT1HEcCiVrW/guyWOBqcMKQAO7lEwQOkk0m7pPTruuTZeMzu'),
(26, '', '', '$2y$10$LAXeeAlRlb.kqjbE4/mSG.WYaU/ehQI/AeP10ZFnS1xyCE9GzUbIK'),
(27, '', '', '$2y$10$6b/XilLLoNsab7mvksKcOuA/BtAJLhtZ/PDUUE6Z.BPauKHSjOFey'),
(28, '', '', '$2y$10$0uEzYCFUgUsoXcphrx7lr.LMXQWk3yHQrm8l22jAJa0IOTDd.i9xy'),
(29, '', '', '$2y$10$AjupinL4BsvmDulSvNeDNer5mCewyBu17UJb9WqZ6elyEEV9Ranse'),
(30, '', '', '$2y$10$STkiRy0icl/sdF.oJT83XuPRfspu9dtWOspgIIY7NmmRsXiUy2sqK');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `curhatan`
--
ALTER TABLE `curhatan`
  ADD PRIMARY KEY (`id_curhat`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `curhatan`
--
ALTER TABLE `curhatan`
  MODIFY `id_curhat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
